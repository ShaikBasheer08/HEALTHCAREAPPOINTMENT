package com.cts.healthcareappointment.notificationmodule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotificationModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
