package com.cts.healthcareappointment.notificationmodule.Entity;

public enum Specialization {
	Cardiology,
	Gynaecology,
	Neurology,
	Dermatology,
	Oncology,
	Psychology,
	Orthodontics,
	Pulmonology,
	Nephrology,
	General
}
 