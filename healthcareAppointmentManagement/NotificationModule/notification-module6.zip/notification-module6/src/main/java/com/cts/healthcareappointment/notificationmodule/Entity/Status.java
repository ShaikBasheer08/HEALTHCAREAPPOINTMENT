package com.cts.healthcareappointment.notificationmodule.Entity;


public enum Status {
    Booked,
    Completed,
    Cancelled;
}